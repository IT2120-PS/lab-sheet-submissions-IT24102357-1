setwd("C:/Desktop/Lab/2Y 1S/PS/IT24102357 lab7 ps")




punif(25,min=0,max=40,lower.tail = TRUE)-punif(10,min=0,max=40,lower.tail = TRUE)


pexp(2,rate = 0.333,lower.tail = TRUE)


1-pnorm(130,mean =100,sd=15)

qnorm(0.95,mean = 100,sd=15)
